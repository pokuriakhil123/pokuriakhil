
class SI
{
    public static void main(String args[])
    {
        int p=500,q=120,r=10;
        int si=(p*q*r)/100;
        System.out.println("the simple interst of si="+si);
    }
}