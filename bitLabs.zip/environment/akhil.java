
class akhil
{
    public static void main(String args[])
    {
        System.out.println("Name - Pokuri Akhil");
        System.out.println("Collge Name - Veltech");
        System.out.println("Branch Name - Mechanical");
    }
}